#ifndef __BUZZER_H
#define __BUZZER_H	 
#include "sys.h"

#define BUZZER_PORT	GPIOB	
#define BUZZER_Pin	GPIO_Pin_0	
#define BUZZER PBout(0)

void BUZZER_Init(void);
void BUZZER_BEEP1(void);
		 				    
#endif
