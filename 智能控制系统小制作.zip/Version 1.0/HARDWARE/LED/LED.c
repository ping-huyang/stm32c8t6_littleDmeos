#include "stm32f10x.h"
#include "led.h"
#include "delay.h"

/*******************************
 * STM32F103C8T6��Сϵͳ���Դ���LED
 * LED->PB13 �͵�ƽ����
 * ****************************/

void LED_Init()
{
	RCC_APB2PeriphClockCmd(LED_CLOCK,ENABLE);
	
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Pin = LED_PIN;
	GPIO_Init(LED_PORT,&GPIO_InitStructure);
	GPIO_SetBits(LED_PORT,LED_PIN);

	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_13;
	GPIO_Init(GPIOC,&GPIO_InitStructure);
	GPIO_SetBits(GPIOC,GPIO_Pin_13);
}

void LED_ON_ALL(void)
{
    GPIO_ResetBits(LED_PORT,GPIO_Pin_12|GPIO_Pin_13|GPIO_Pin_14|GPIO_Pin_15);
}

void LED_OFF_ALL(void)
{
    GPIO_SetBits(LED_PORT,GPIO_Pin_12|GPIO_Pin_13|GPIO_Pin_14|GPIO_Pin_15);
}

void LED_ON(u8 whichOne)
{
    switch (whichOne)
    {
    case 1:
        GPIO_ResetBits(LED_PORT,GPIO_Pin_12);
        break;
    case 2:
        GPIO_ResetBits(LED_PORT,GPIO_Pin_13);
        break;
    case 3:
        GPIO_ResetBits(LED_PORT,GPIO_Pin_14);
        break;
    case 4:
        GPIO_ResetBits(LED_PORT,GPIO_Pin_15);
        break;
    }
}

void LED_OFF(u8 whichOne)
{
    switch (whichOne)
    {
    case 1:
        GPIO_SetBits(LED_PORT,GPIO_Pin_12);
        break;
    case 2:
        GPIO_SetBits(LED_PORT,GPIO_Pin_13);
        break;
    case 3:
        GPIO_SetBits(LED_PORT,GPIO_Pin_14);
        break;
    case 4:
        GPIO_SetBits(LED_PORT,GPIO_Pin_15);
        break;
    }
}

void LED_TURN(u8 whichOne)
{
    switch (whichOne)
    {
    case 1:
        GPIO_WriteBit(LED_PORT,GPIO_Pin_12,(BitAction)(1-GPIO_ReadOutputDataBit(LED_PORT,GPIO_Pin_12)));
        break;
    case 2:
        GPIO_WriteBit(LED_PORT,GPIO_Pin_13,(BitAction)(1-GPIO_ReadOutputDataBit(LED_PORT,GPIO_Pin_13)));
        break;
    case 3:
        GPIO_WriteBit(LED_PORT,GPIO_Pin_14,(BitAction)(1-GPIO_ReadOutputDataBit(LED_PORT,GPIO_Pin_14)));
        break;
    case 4:
        GPIO_WriteBit(LED_PORT,GPIO_Pin_15,(BitAction)(1-GPIO_ReadOutputDataBit(LED_PORT,GPIO_Pin_15)));
        break;
    case 5:
        GPIO_WriteBit(GPIOC,GPIO_Pin_13,(BitAction)(1-GPIO_ReadOutputDataBit(GPIOC,GPIO_Pin_13)));
        break;
    } 
}

uint8_t LED_TURN_Return(u8 whichOne)
{
    switch (whichOne)
    {
    case 1:
        GPIO_WriteBit(LED_PORT,GPIO_Pin_12,(BitAction)(1-GPIO_ReadOutputDataBit(LED_PORT,GPIO_Pin_12)));
        return 1 - GPIO_ReadOutputDataBit(LED_PORT,GPIO_Pin_12);
    case 2:
        GPIO_WriteBit(LED_PORT,GPIO_Pin_13,(BitAction)(1-GPIO_ReadOutputDataBit(LED_PORT,GPIO_Pin_13)));
        return 1 - GPIO_ReadOutputDataBit(LED_PORT,GPIO_Pin_13);
    case 3:
        GPIO_WriteBit(LED_PORT,GPIO_Pin_14,(BitAction)(1-GPIO_ReadOutputDataBit(LED_PORT,GPIO_Pin_14)));
        return 1 - GPIO_ReadOutputDataBit(LED_PORT,GPIO_Pin_14);
    case 4:
        GPIO_WriteBit(LED_PORT,GPIO_Pin_15,(BitAction)(1-GPIO_ReadOutputDataBit(LED_PORT,GPIO_Pin_15)));
        return 1 - GPIO_ReadOutputDataBit(LED_PORT,GPIO_Pin_15);
    }
    return 2;
}

