#ifndef __LED_H__
#define __LED_H__
#include "sys.h"

#define LED_CLOCK RCC_APB2Periph_GPIOB|RCC_APB2Periph_GPIOC
#define LED_PORT GPIOB
#define LED_PIN GPIO_Pin_12|GPIO_Pin_13|GPIO_Pin_14|GPIO_Pin_15

void LED_ON_ALL(void);
void LED_OFF_ALL(void);
void LED_ON(u8 whichOne);
void LED_OFF(u8 whichOne);
void LED_TURN(u8 whichOne);
uint8_t LED_TURN_Return(u8 whichOne);
void LED_Init(void);

#endif

