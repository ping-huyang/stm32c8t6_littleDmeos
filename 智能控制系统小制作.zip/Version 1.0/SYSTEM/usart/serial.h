#ifndef __SERIAL_H
#define __SERIAL_H
#include "sys.h" 
#define EN_USART3_RX 1

void Serial_SendByte(uint8_t Byte);
void Serial_SendArray(uint8_t *Array, uint16_t Length);
void Serial_init(u32 bound);

#endif
