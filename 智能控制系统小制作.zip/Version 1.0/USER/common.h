#ifndef __COMMON_H__
#define __COMMON_H__

#include "delay.h"
#include "sys.h"
#include "led.h"
#include "usart.h"
#include "serial.h"
#include "buzzer.h"
#include "OLED.h"
#include "key.h"

#endif

