#ifndef __AD_H
#define __AD_H

extern unsigned short int AD_Value[4];

void AD_Init(void);

#endif
