#ifndef __AD_H
#define __AD_H

extern unsigned short int  AD_Value[3];
	
void AD_Init(void);
void AD_GetValue(void);

#endif
