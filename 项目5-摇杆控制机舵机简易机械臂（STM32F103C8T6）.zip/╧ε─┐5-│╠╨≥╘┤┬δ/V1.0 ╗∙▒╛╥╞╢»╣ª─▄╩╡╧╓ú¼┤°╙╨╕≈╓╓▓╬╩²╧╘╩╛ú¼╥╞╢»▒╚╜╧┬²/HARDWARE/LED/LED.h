#ifndef __LED_H__
#define __LED_H__
#include "sys.h"

#define LED_CLOCK RCC_APB2Periph_GPIOC
#define LED_PORT GPIOC
#define LED_PIN GPIO_Pin_13

#define LED PCout(13)

void LED_ON(void);
void LED_OFF(void);
void LED_TURN(void);
void LED_Blink(void);
void LED_Init(void);
#endif

