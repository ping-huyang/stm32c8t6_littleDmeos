#include "stm32f10x.h"
#include "delay.h"
#include "usart.h"
#include "sys.h"
#include "led.h"
#include "OLED.h"
#include "Servo.h"
#include "AD.h"

//AD_Value[0]->Y    AD_Value[1]->X  AD_Value[2]->Z

int Angle1 = 0;  //0~190   �·��Ķ��
int Angle2 = 30;  //30~180  �Ϸ��Ķ��
int Speed = 4;

void Action(void);

int main(void)
{
    NVIC_Configuration();
    RCC_Configuration();
    AD_Init();
    LED_Init();
	OLED_Init();
    Servo_Init();

    OLED_ShowString(1,1,"Servo_Demo");
    OLED_ShowString(2,1,"Angle1:");
    OLED_ShowString(3,1,"Angle2:");
    OLED_ShowString(4,1,"Speed:");
    OLED_ShowNum(2,8,Angle1,3);
    OLED_ShowNum(3,8,Angle2,3);
    OLED_ShowNum(4,8,20-Speed,3);
    Servo_SetAngle2(Angle2);
    Servo_SetAngle(Angle1);

	while (1)
	{
        Action();
	}
}

void Action()
{
    //ҡ��������
    if(AD_Value[0] > 3000)
    {
        if(Angle2 < 180)
        {
            Angle2++;
            Servo_SetAngle2(Angle2);
            OLED_ShowNum(3,8,Angle2,3);
            delay_ms(Speed);
        }
    }
    //ҡ�������ƶ�
    if(AD_Value[0] < 1000)
    {
        if(Angle2 > 32)
        {
            Angle2--;
            Servo_SetAngle2(Angle2);
            OLED_ShowNum(3,8,Angle2,3);
            delay_ms(Speed);
        }
    }
    //ҡ�������ƶ�
    if(AD_Value[1] < 1000)
    {
        if(Angle1 < 188)
        {
            Angle1++;
            Servo_SetAngle(Angle1);
            OLED_ShowNum(2,8,Angle1,3);
            delay_ms(Speed);
        }
    }
    //ҡ�������ƶ�
    if(AD_Value[1] > 3000)
    {
        if(Angle1 > 3)
        {
            Angle1--;
            Servo_SetAngle(Angle1);
            OLED_ShowNum(2,8,Angle1,3);
            delay_ms(Speed);
        }
    }
    //ҡ�����°�
    if(AD_Value[2] < 1000)
    {
        Speed--;
        if(Speed == 0)
		{
			OLED_ShowString(4,8,"MAX");
		}else if(Speed < 0)
		{
			Speed = 20;
		}else
		{
			OLED_ShowNum(4,8,20-Speed,3);
		}
        delay_ms(200);
    }
}

